# HSF – Endoscopia | Dashboard de Sobreaviso

Versão web estática do dashboard de sobreaviso, pronta para publicação gratuita no **GitHub Pages**.

## Arquivos

- `index.html` — página principal
- `style.css` — aparência do dashboard
- `app.js` — escala e lógica automática

## Publicar gratuitamente no GitHub Pages

1. Crie uma conta em https://github.com, caso ainda não tenha.
2. Clique em **New repository**.
3. Dê um nome, por exemplo: `hsf-endoscopia`.
4. Deixe o repositório como **Public**.
5. Envie os arquivos `index.html`, `style.css` e `app.js`.
6. No repositório, abra **Settings**.
7. Vá em **Pages**.
8. Em **Build and deployment**, escolha:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/ (root)**
9. Clique em **Save**.
10. Depois de publicado, o endereço ficará aproximadamente assim:
   `https://SEU-USUARIO.github.io/hsf-endoscopia/`

## Como a escala funciona

A versão atual contém a escala de **28/08/2026 até 31/12/2027**.

Regras incorporadas:

- 28, 29, 30 e 31/08/2026: Alexandre
- 01 a 13/09/2026: distribuição específica informada
- Desde 14/09/2026:
  - segunda, quarta e sexta: José Henrique
  - terça, quinta, sábado e domingo: alternância semanal entre Luciana e Alexandre
  - semana iniciada em 14/09/2026: Luciana
  - semana seguinte: Alexandre
  - e assim sucessivamente

## Alterar a escala

A escala fica no início do arquivo `app.js`, no objeto `schedule`.

Cada linha tem este formato:

```javascript
"2026-09-14":{"name":"Dr. José Henrique","phone":"(16) 99723-3391"}
```

Depois de alterar e salvar o arquivo no GitHub, o site é atualizado automaticamente.

## Observação

A página usa apenas HTML, CSS e JavaScript. Não necessita servidor, banco de dados ou serviço pago.
